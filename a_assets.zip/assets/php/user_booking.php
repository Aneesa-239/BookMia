<?php
require_once "config.php";

$patientcount = "Select COUNT(*) from Booking";
$last = mysqli_query($conn, $patientcount);
$row = [];

if ($last->num_rows > 0) {
    // fetch all data from db into array 
    $row = $last->fetch_all(MYSQLI_ASSOC);
}
if (!empty($row))
    foreach ($row as $rows) {
        $number = $rows['COUNT(*)'] + 1;
    }

$startdate = $_GET['startdate'];
$enddate = $_GET['enddate'];
$user = $_GET['patientCode'];
$doctor = $_GET['doctorCode'];
$doc_email = $_GET['email'];


if ($startdate !== "" and $enddate !== "") {

    $string = "INSERT INTO Booking SET 
                BookingCode = 'BC00$number',PatientCode = (SELECT PatientCode
                FROM Patient
                WHERE PatientCode = '$user'),DoctorCode =(SELECT DoctorCode FROM Doctor WHERE DoctorCode = '$doctor'),StartDate ='$startdate', EndDate ='$enddate',BookingStatus = 'Active' ";
    $check = mysqli_query($conn, $string);
} else {
    header("Location: ../../booking.php?flag=true");
}

if ($check) {

    $string2 = "INSERT INTO Invoice SET BookingCode=(SELECT BookingCode  FROM Booking Where BookingCode = 'BC00$number'); ";
    $check2 = mysqli_query($conn, $string2);
} else {
    header("Location: ../../booking.php?flag=true");
}

if ($check2) {
    $string3 = "INSERT INTO Payment SET PaymentAmount = (SELECT Fees FROM Doctor Where DoctorCode = '$doctor'),
                        InvoiceCode=(SELECT MAX(InvoiceCode) FROM Invoice ORDER BY InvoiceCode), PaymentStatus= 'Pending'";
    $check3 = mysqli_query($conn, $string3);
} else {
    header("Location: ../../booking.php?flag=true");
}

if ($check3) {
    $query = "SELECT BookingCode  FROM Booking Where BookingCode LIKE '%$number'";
    $result = mysqli_query($conn, $query);
    $row2 = [];

    if ($result->num_rows > 0) {
        // fetch all data from db into array 
        $row2 = $result->fetch_all(MYSQLI_ASSOC);
    }

    if (!empty($row2))
        foreach ($row2 as $rows2) {

            $code = $rows2['BookingCode'];
        }
    header("Location: ../../booking.php?id=$doc_email&flag=false&code=$code&choice=$startdate");
} else {
    header("Location: ../../booking.php?flag=true");
}





?>